# HBP LAW FIRM — Advocates & Legal Consultants

## Cara Upload ke GitHub Pages
1. Buka [https://github.com/new](https://github.com/new)
2. Buat repository baru bernama `hbp-lawfirm`
3. Upload file `index.html` ke repo tersebut
4. Buka tab **Settings > Pages**
5. Di bagian 'Build and deployment', pilih **Deploy from branch**
6. Pilih branch `main` dan folder `/ (root)` lalu klik Save
7. Tunggu 1-2 menit, website akan aktif di: `https://username.github.io/hbp-lawfirm`

## Cara Edit
- Buka file `index.html`
- Temukan bagian `<div class="adv">` untuk menambah atau ubah data advokat
- Untuk ubah kontak kantor, edit bagian di `<aside class="card contact">`

